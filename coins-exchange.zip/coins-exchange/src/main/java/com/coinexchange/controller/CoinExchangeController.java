package com.coinexchange.controller;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.coinexchange.exception.InValidInputException;
import com.coinexchange.service.CoinExchangeService;

@RestController
public class CoinExchangeController {
	
	@Autowired
	private CoinExchangeService coinExchangeService;
	
	@GetMapping("/coin-exchange/{money}")
	public ResponseEntity<Object> convertMoneyToCoins(@PathVariable String money) {
		int moneyValue = 0;
		try {
			moneyValue = Integer.parseInt(money);
		}catch(Exception ex) {
			throw new InValidInputException("Invalid Input");
		}
		
		if(moneyValue == 0) {
			throw new InValidInputException("Invalid Input");
		}
		
		Map<BigDecimal, Integer> outputMap = coinExchangeService.getCoinsForCurrency(new BigDecimal(moneyValue), "less-coins");
		
		return new ResponseEntity<>(outputMap, HttpStatus.OK);
	}
	
	@GetMapping("/coin-exchange/{money}/{requestType}")
	public ResponseEntity<Object> convertMoneyToCoinsBasedCoinsCount(@PathVariable String money, @PathVariable String requestType) {
		int moneyValue = 0;
		try {
			moneyValue = Integer.parseInt(money);
		}catch(Exception ex) {
			throw new InValidInputException("Invalid Input");
		}
		
		if(moneyValue == 0 || !(requestType.equals("less-coins") || requestType.equals("more-coins"))) {
			throw new InValidInputException("Invalid Input");
		}
		
		Map<BigDecimal, Integer> outputMap = coinExchangeService.getCoinsForCurrency(new BigDecimal(moneyValue), "more-coins");
		
		return new ResponseEntity<>(outputMap, HttpStatus.OK);
	}

}
