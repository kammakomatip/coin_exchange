package com.coinexchange.config;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class ConfigurationHandler {
	
	@Autowired
	private Environment environment;
	
	private Map<BigDecimal, Integer> coinsMap = new HashMap();
	
	public Map<BigDecimal, Integer> initialMap() {
		int coinsCount = Integer.parseInt(environment.getProperty("each.coins.count"));
		coinsMap.put(new BigDecimal("0.01"), coinsCount);
		coinsMap.put(new BigDecimal("0.05"), coinsCount);
		coinsMap.put(new BigDecimal("0.10"), coinsCount);
		coinsMap.put(new BigDecimal("0.25"), coinsCount);
		return coinsMap;
	}

	public Map<BigDecimal, Integer> getCoinsMap() {
		return coinsMap;
	}

	public void setCoinsMap(Map<BigDecimal, Integer> coinsMap) {
		this.coinsMap = coinsMap;
	}
}
