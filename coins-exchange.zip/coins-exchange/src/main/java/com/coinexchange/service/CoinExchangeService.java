package com.coinexchange.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coinexchange.config.ConfigurationHandler;
import com.coinexchange.exception.OutOfCoinsException;

@Component
public class CoinExchangeService {
	
	@Autowired
	private ConfigurationHandler config;
	
	public Map<BigDecimal, Integer> getCoinsForCurrency(BigDecimal moneyValue, String requestType) {
		Map<BigDecimal, Integer> coinsMap = config.getCoinsMap();
		if(coinsMap.size() == 0) {
			coinsMap = config.initialMap();
			config.setCoinsMap(coinsMap);
		}
		
		boolean success = false;
		Map<BigDecimal, Integer> outputMap = new HashMap();
		Map<BigDecimal, Integer> sortedMap = null;
		if(requestType == "more-coins") {
			sortedMap = coinsMap.entrySet().stream()
	                .sorted(Map.Entry.comparingByKey())
	                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
	                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		}else {
			sortedMap = coinsMap.entrySet().stream()
	                .sorted(Collections.reverseOrder(Map.Entry.comparingByKey()))
	                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
	                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));
		}
		System.out.println(coinsMap);
		System.out.println(sortedMap);
		System.out.println(moneyValue);
		for(Map.Entry<BigDecimal, Integer> map: sortedMap.entrySet()) {
			BigDecimal coin = map.getKey();
			int coinCount = map.getValue();
			System.out.println(coin);
			System.out.println(coinCount);
			BigDecimal amount = new BigDecimal(0);
			for(int index=1; index <= coinCount; index++) {
				amount = coin.multiply(BigDecimal.valueOf(index));
				System.out.println(amount);
				if(amount.intValue() == (moneyValue.intValue())) {
					outputMap.put(coin, index);
					success = true;
					break;
				}
			}
			//System.out.println("11 ==>"+amount);
			if(amount.intValue() == (moneyValue.intValue())) {
				System.out.println("11 ==>"+amount);
				coinsMap.put(coin, (coinCount-outputMap.get(coin)));
				success = true;
				break;
			}else {
				outputMap.put(coin, coinCount);
				coinsMap.put(coin, (coinCount-outputMap.get(coin)));
			}
			
			moneyValue = moneyValue.subtract(amount);
			System.out.println("moneyValue ==> "+moneyValue);
			//coinsMap.put(coin, null)
		}
		if(success) {
			System.out.println(outputMap);
		}else {
			throw new OutOfCoinsException("Do not have enough coins");
		}
		
		return outputMap;
		
	}

}
