package com.coinexchange.exception;

public class InValidInputException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7813056860557523847L;
	
	private String message;

	public InValidInputException() {
		
	}
	
	public InValidInputException(String message) {
		super(message);
		this.message = message;
	}
}
