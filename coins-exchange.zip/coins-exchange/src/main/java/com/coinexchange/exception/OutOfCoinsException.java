package com.coinexchange.exception;

public class OutOfCoinsException extends RuntimeException {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6015148602653593608L;
	private String message;

	public OutOfCoinsException() {
		
	}
	
	public OutOfCoinsException(String message) {
		super(message);
		this.message = message;
	}
}
