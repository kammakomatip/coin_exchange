package com.coinexchange.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(value = InValidInputException.class)
	public ResponseEntity<Object> invalidInputException(InValidInputException ex) {
		return new ResponseEntity<>("Invalid Input", HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value = OutOfCoinsException.class)
	public ResponseEntity<Object> outOfCoinsException(OutOfCoinsException ex) {
		return new ResponseEntity<>("Do not have enough coins", HttpStatus.BAD_REQUEST);
	}
}
