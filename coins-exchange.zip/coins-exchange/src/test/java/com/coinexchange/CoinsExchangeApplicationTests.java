package com.coinexchange;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.coinexchange.config.ConfigurationHandler;
import com.coinexchange.controller.CoinExchangeController;
import com.coinexchange.service.CoinExchangeService;

@SpringBootTest
class CoinsExchangeApplicationTests {
	
	@InjectMocks
	CoinExchangeController controller;
	
	@Autowired
	ConfigurationHandler config;
	
	@Mock
	private CoinExchangeService coinExchangeService;

	@Test
	public void coinExchangeCountsTest() {
		ResponseEntity<Object> responseEntity = controller.convertMoneyToCoins("10");
		System.out.println(responseEntity);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void contextLoads() {
	}
	
	
	
	

}
